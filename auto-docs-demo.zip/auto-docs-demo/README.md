# auto-docs-demo

Demo CI/CD build tài liệu tự động với GitHub Actions.

## Hướng dẫn

1. Clone repository
2. Chạy lệnh: `pip install -r requirements.txt`
3. Build tài liệu: `mkdocs build`
4. Upload code lên GitHub, CI/CD sẽ tự chạy và deploy tài liệu lên GitHub Pages.