# 📘 Tài liệu dự án

Trang này được sinh tự động bằng GitHub Actions.

- Hệ thống CI/CD tự build mỗi khi có thay đổi.
- Dùng MkDocs + Material.

## Ví dụ hàm Python

```python
from src.main import xin_chao
print(xin_chao("Nam"))